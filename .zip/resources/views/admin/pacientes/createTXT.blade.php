<!DOCTYPE html>
<html>
    {{$lineas}}
    </html>