

<?php $__env->startSection('title', 'Nuevo Profesional'); ?>


<?php $__env->startSection('content_header'); ?>
<h1>Nuevo Profesional</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="cadr-body">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <?php if(isset($profesional)): ?>
                    <?php echo e(Form::model($profesional,['route'=>['admin.profesionales.update', $profesional->id],'method' => 'PUT', 'role'=>'form', 'data-toggle'=>'validator'])); ?>

                    <?php else: ?>
                    <?php echo e(Form::open(['route' => 'admin.profesionales.store','method'=>'POST', 'role'=>'form', 'data-toggle'=>'validator'])); ?>

                    <?php endif; ?>

                    <?php if(isset($profesional->id)): ?>
                    <div class="row col-md-12">
                        <div class="form-group col-md-6">
                            <label for="id">Id</label>
                            <?php echo e(Form::text('id', null, array('id' => 'id','class' => 'form-control','placeholder'=>"id", 'readonly'))); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="row col-md-12">
                   
                        <div class="col-md-6 form-group has-feedback">
                            <label for="nombre">Nombre</label>
                            <?php echo e(Form::text('nombre', null, array('id' => 'nombre','class' => 'form-control','placeholder' => 'Nombre'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                        
                        <div class="col-md-6 form-group has-feedback">
                            <label for="cuit">CUIT</label>
                            <?php echo e(Form::text('cuit', null, array('id' => 'cuit','class' => 'form-control','placeholder' => 'CUIT'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>

                    </div>

                    <div class="row col-md-12">
                        <div class="col-md-6 form-group has-feedback">
                            <label for="matricula">Matrícula</label>
                            <?php echo e(Form::text('matricula', null, array('id' => 'matricula','class' => 'form-control','placeholder' => 'Matricula'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                        <div class="col-md-6 form-group has-feedback">
                            <label for="telefono">Teléfono</label>
                            <?php echo e(Form::text('telefono', null, array('id' => 'telefono','class' => 'form-control','placeholder' => 'Telefono'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                    </div>



                    <div class="row col-md-12">
                        <div class="col-md-6 form-group has-feedback">
                            <label for="mail">Mail</label>
                            <?php echo e(Form::text('mail', null, array('id' => 'mail','class' => 'form-control','placeholder' => 'Mail'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                        <div class="col-md-6 form-group has-feedback">
                            <label for="id_profesion">Profesion</label>
                            <?php echo e(Form::select('id_profesion', $profesiones, null,  array('id' => 'id_profesion','class' => 'form-control select2'))); ?>

                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                    </div>
      
                </div>


                    <div class="box-footer col-md-6 form-group pull-right ">
                        <a type="button" class="btn btn-outline-danger" href="<?php echo e(route('admin.profesionales.index')); ?>"><?php echo e(trans('message.close')); ?></a>
                        <button type="submit" class="btn btn-outline-primary"><?php echo e(trans('message.save')); ?></button>
                    </div>
                    <?php echo e(Form::close()); ?>

                    <!-- /.box-body -->
                </div>
            </div>
            <!-- /.box -->
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\turnos.mp\resources\views/admin/profesionales/edit.blade.php ENDPATH**/ ?>